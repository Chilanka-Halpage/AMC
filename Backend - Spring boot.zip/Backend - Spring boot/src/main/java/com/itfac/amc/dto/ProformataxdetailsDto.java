package com.itfac.amc.dto;

public interface ProformataxdetailsDto {

}
