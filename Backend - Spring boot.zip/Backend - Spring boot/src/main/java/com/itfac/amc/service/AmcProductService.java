package com.itfac.amc.service;

import com.itfac.amc.entity.AmcProduct;

public interface AmcProductService {

	AmcProduct saveAmcProduct(AmcProduct amcProduct) throws Exception;
}
