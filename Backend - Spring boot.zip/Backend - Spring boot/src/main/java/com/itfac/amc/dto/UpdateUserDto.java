package com.itfac.amc.dto;

public interface UpdateUserDto {
	
	String getUname(); 
	String getEmail();
	String getContactNo();
	String getPassword();

}
