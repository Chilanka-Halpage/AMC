package com.itfac.amc.reportData;



public interface UserDetails {
	public String getuser_id();
	public String getuname();
	public String getrole();
	public boolean getactive();
	public String getemail();
	public String getconatact_no();
}
