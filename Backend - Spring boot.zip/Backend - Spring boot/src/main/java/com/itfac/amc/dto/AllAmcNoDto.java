package com.itfac.amc.dto;

public interface AllAmcNoDto {
	
	String getamcNo(); 

}
