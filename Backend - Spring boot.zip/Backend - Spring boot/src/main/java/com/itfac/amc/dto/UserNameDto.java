package com.itfac.amc.dto;

import org.springframework.stereotype.Component;

@Component
public interface UserNameDto {

	String getUname(); 
}
