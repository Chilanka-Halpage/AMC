package com.itfac.amc.dto;

public interface ClientDto {
	String getClientName();
	boolean active();
	String getContactNo();
	String getContactPerson();
	String getAddress();
}
