package com.itfac.amc.dto;

public interface ClientDepartmentDto {
	String getDepartmentName();
}
