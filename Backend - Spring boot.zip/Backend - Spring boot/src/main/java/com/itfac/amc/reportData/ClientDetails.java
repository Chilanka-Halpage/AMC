package com.itfac.amc.reportData;

import java.util.Date;

public interface ClientDetails {

	public String getuser_id();
	public String getcontact_no();
	public String getcontact_person();
	public String getaddress();
	public boolean getactive();
	public String getamc_no();
	public Date getstart_date();
	public String getclient_name();

}
