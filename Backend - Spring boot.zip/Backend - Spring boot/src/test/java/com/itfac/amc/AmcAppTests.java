package com.itfac.amc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmcAppTests {

	@Test
	void contextLoads() {
	}

}
