import { TableFiterPipe } from './table-fiter.pipe';

describe('TableFiterPipe', () => {
  it('create an instance', () => {
    const pipe = new TableFiterPipe();
    expect(pipe).toBeTruthy();
  });
});
