export class Frequency {
    frequencyId: number;
    frequencyName: string;
    active?: boolean;
}