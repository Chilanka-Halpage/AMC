export class Client {
    clietnID: string;
    clientName: string;
    active;
    contactNo: string;
    contactPerson: string;
    address: string;
    savedIp?: string;
    savedBy?: string;
    savedOn?: Date;
    lastModifiedBy?: Date;
    lastModifiedOn?: Date;
}