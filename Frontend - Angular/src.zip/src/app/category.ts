export class Category {
    id: number;
    categoryName: string;
    active: boolean;
    savedBy: string;
    savedOn:Date;
    savedIp: string;
    lastModifiedBy: string;
    lastModifiedOn: Date;
}