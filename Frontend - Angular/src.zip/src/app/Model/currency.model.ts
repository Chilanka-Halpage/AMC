export class Currency {
    currencyId: number;
    currencyName: string;
    active?: boolean;
}