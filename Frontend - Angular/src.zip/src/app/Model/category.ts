export class Category {
    categoryId: number;
    categoryName: string;
    active: boolean;
    savedBy: string;
    savedOn: Date;
    savedIp: string;
}
