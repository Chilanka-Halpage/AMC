export class Frequency {
    frequencyId: number;
    frequency: string;
    active: boolean;
}