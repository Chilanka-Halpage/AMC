export class frequency {
    id: number;
    frequency: string;
    active: boolean;
    savedBy: string;
    savedOn:Date;
    savedIp: string;
    lastModifiedBy:string;
    lastModifiedOn:Date;
}