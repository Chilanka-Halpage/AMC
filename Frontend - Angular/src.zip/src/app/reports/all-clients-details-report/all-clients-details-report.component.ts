import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-clients-details-report',
  templateUrl: './all-clients-details-report.component.html',
  styleUrls: ['./all-clients-details-report.component.scss']
})
export class AllClientsDetailsReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
