import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-invoice',
  templateUrl: './update-invoice.component.html',
  styleUrls: ['./update-invoice.component.scss']
})
export class UpdateInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
