import { RenewalAmcs } from './renewal-amcs';

describe('RenewalAmcs', () => {
  it('should create an instance', () => {
    expect(new RenewalAmcs()).toBeTruthy();
  });
});
