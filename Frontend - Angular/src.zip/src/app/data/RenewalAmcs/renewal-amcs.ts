export class RenewalAmcs {
    amc_no : String
	amc_serial_no :String
	renewal : Date
	user_id :String
	client_name :String
	category_name :String
	frequency :String
	currency_name : String
	invoice_amount :number
	total_value_lkr : number
	mtc_qty :number
}
