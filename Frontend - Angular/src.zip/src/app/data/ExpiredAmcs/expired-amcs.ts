export class ExpiredAmcs {
    amc_no : String
	due_date : Date
	category_name : String
	client_name : String
	contact_no : String
	frequency : String
	invoice_amount : number
	total_value_lkr : number
}
