import { ExpiredAmcs } from './expired-amcs';

describe('ExpiredAmcs', () => {
  it('should create an instance', () => {
    expect(new ExpiredAmcs()).toBeTruthy();
  });
});
