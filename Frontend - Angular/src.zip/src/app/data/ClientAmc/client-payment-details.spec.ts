import { ClientPaymentDetails } from './client-payment-details';

describe('ClientPaymentDetails', () => {
  it('should create an instance', () => {
    expect(new ClientPaymentDetails()).toBeTruthy();
  });
});
