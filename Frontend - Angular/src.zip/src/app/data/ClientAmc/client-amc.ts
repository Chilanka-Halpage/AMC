export class ClientAmc {
    client_id: String
	amc_no: String
	start_date: Date
	category_name: String
	amc_product_no: number
	product_description: String
	department_name: String
	amc_serial_no: String
	frequency: String
	mtc_start_date: Date
	mtc_end_date: Date
}
