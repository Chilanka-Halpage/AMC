import { ClientAmc } from './client-amc';

describe('ClientAmc', () => {
  it('should create an instance', () => {
    expect(new ClientAmc()).toBeTruthy();
  });
});
