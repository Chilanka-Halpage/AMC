export class ClientPaymentDetails {
}
