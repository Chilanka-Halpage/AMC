export class Notification {
notification_id: number
notification: String
saved_date: Date 
user_id: String 
is_read: boolean
}
