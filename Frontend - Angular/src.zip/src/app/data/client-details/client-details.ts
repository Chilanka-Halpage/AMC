export class ClientDetails {
    user_id :string
	contact_no : string
	contact_person : string
	address :string
	active :boolean
	amc_no :string
	start_date :Date
    client_name : String

}

