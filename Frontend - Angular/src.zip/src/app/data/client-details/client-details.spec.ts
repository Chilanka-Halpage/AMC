import { ClientDetails } from './client-details';

describe('ClientDetails', () => {
  it('should create an instance', () => {
    expect(new ClientDetails()).toBeTruthy();
  });
});
