export class AllAmcs {
    amc_no: String
    start_date: Date
    client_name: String
    contact_person: String
    category_name: String
    frequency: String
    currency_name: String
    exchage_rate: String
    mtc_qty: number
    total_value_lkr: number
    active: boolean
}