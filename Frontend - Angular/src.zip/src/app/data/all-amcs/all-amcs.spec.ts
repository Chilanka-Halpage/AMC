import { AllAmcs } from './all-amcs';

describe('AllAmcs', () => {
  it('should create an instance', () => {
    expect(new AllAmcs()).toBeTruthy();
  });
});
