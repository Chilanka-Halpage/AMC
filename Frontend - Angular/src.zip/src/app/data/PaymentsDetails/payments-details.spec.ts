import { PaymentsDetails } from './payments-details';

describe('PaymentsDetails', () => {
  it('should create an instance', () => {
    expect(new PaymentsDetails()).toBeTruthy();
  });
});
