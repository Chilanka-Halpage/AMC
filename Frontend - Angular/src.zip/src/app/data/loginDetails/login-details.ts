export class LoginDetails {
    user_id : String
    uname : String
    loged_ip : String
    loged_datetime : Date
}
