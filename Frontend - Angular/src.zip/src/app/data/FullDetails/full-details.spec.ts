import { FullDetails } from './full-details';

describe('FullDetails', () => {
  it('should create an instance', () => {
    expect(new FullDetails()).toBeTruthy();
  });
});
