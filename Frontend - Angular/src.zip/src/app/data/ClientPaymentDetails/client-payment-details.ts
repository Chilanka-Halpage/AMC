export class ClientPaymentDetails {
    amc_no : String
	amc_serial_no : String
	rec_date : Date
	product_name : String
    currency_name :String
	exchage_rate : number
	total : number
	total_lkr : number
	client_id : String
}
