export class RenewedAmcs {
    amc_no : String
	amc_serial_no :String
	mtc_start_date :Date
	client_name : String
	category_name : String
	mtc_qty : number
	frequency : String
	currency_name : String
	exchage_rate : number
	invoice_amount : number
	total_value_lkr : number
}
