import { RenewedAmcs } from './renewed-amcs';

describe('RenewedAmcs', () => {
  it('should create an instance', () => {
    expect(new RenewedAmcs()).toBeTruthy();
  });
});
