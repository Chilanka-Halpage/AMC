export class Users {
userId: String;
uname: String;
password: String
role: String;
active: boolean;
email: String;
contactNo: String;
}
