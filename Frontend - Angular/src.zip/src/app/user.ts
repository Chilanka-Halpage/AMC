export class user {
    id: number;
    uname: string;
    password:string;
    role:string;
    active:boolean;
    email:string;
    contactNo:string;
}