export class Tax {
    taxId: number;
    taxName: string;
    shortName: string;
    taxRate: number;
    savedOn: Date;
    savedIp: string;
    active: boolean;
}
