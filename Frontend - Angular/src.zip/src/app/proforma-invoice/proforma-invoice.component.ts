import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proforma-invoice',
  templateUrl: './proforma-invoice.component.html',
  styleUrls: ['./proforma-invoice.component.scss']
})
export class ProformaInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
