/* export class Homedetalis {
    amcNo: number;
    ActiveAMC: number;
}
 */