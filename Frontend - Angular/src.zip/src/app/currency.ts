export class Currency {

    currency_id: number;
    currencyName: string;
    active: boolean;
    savedBy: string;
    savedOn: string;
    savedIp: string;

}
