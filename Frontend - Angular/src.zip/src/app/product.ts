export class product {
    id: number;
    productName: string;
    active: boolean;
    savedBy: string;
    savedOn:Date;
    savedIp: string;
    lastModifiedBy: string;
    lastModifiedOn: Date;
}