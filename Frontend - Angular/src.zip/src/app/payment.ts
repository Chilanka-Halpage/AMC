 export class Payment {
/* 
 recNo: string;
  recDate: Date;
  exchageRate: number;
  payMode: string;
  total: number;
  balance: number;
  totalLkr: number;
  balanceLkr: number;
  savedBy: string;
  savedOn: number;
  savedIp: string;  
  description: string;
  cancel: boolean;
  cancelReason: string;  */
}
 