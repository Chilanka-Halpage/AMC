export class DuePayment {

      /*   id: number;
        due_date: Date;
        invoiceAmt: number;
        invoice_balance: number;
        Settle: string;
        totalAmt: number;
        amcNo: string;
        amcSerialNo: string;
        productId: number;
        currencyId: number; 
           */
    }
    